package com.dlmsmini.control;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String ESP_URL = "http://192.168.4.1/";
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,21,34));
        getWindow().setNavigationBarColor(Color.rgb(16,21,34));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16,21,34));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(14, 8, 14, 8);
        bar.setBackgroundColor(Color.rgb(23,38,62));

        TextView title = new TextView(this);
        title.setText("DLMS MINI CONTROL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setTypeface(null, 1);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button reload = new Button(this);
        reload.setText("MUAT ULANG");
        reload.setOnClickListener(v -> loadController());
        bar.addView(reload);
        root.addView(bar);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,21,34));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMixedContentMode(0);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView view, int code, String desc, String url) {
                Toast.makeText(MainActivity.this,
                    "Tidak dapat mengakses ESP32. Sambungkan HP ke WiFi DLMS-MINI.",
                    Toast.LENGTH_LONG).show();
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        loadController();
    }

    private void loadController() {
        if (webView != null) webView.loadUrl(ESP_URL);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
