# DLMS MINI CONTROL Android app

This Android Studio project is a lightweight WebView wrapper for the ESP32-hosted DLMS control page.

## ESP32 connection
1. Flash the ESP32 firmware that starts the access point `DLMS-MINI`.
2. Connect Android to that Wi-Fi network (password in the current example firmware: `dlms12345`).
3. Open this app. It loads `http://192.168.4.1/`.
4. Internet access is not required.

## Build APK
1. Install Android Studio (Hedgehog or newer) and Android SDK Platform 35.
2. Open this folder as a project.
3. Wait for Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important functionality note
This APK is the Android shell. The actual controls and DSP parameters are served by the ESP32 firmware. The earlier ESP32 example has UI and preset scaffolding, but crossover, delay, mute and EQ must be mapped to the actual SigmaStudio-exported ADAU1701 parameter addresses before they can control audio. Do not treat the example firmware as a validated production DSP controller.
